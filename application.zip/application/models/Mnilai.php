<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Mnilai extends CI_Model
{
	function nilai_siswa($id_mapel)
	{
		$this->db->where('mapel_id',$id_mapel);
		$this->db->join('kategori_nilai','kategori_nilai.id_kategorinilai = nilai_siswa.kategori_nilai_id');
		$this->db->join('jenis_nilai_akhir','jenis_nilai_akhir.id_jenis_na = nilai_siswa.jenis_na_id');
		$data = $this->db->get('nilai_siswa');

		return $data->result_array();
	}
	function tampil_jenis_nilai()
	{
		$data = $this->db->get('jenis_nilai_akhir');
		return $data ->result_array();
	}
	function tampil_kategori_nilai()
	{
		$data = $this->db->get('kategori_nilai');
		return $data ->result_array();
	}
	function simpan_nilai($inputan)
	{
		$this->db->insert('nilai_siswa',$inputan);
	}
	function nilai_siswa_per_mapel($nisn,$mapel)
	{
		$this->db->join('jenis_nilai_akhir','jenis_nilai_akhir.id_jenis_na = nilai_siswa.jenis_na_id');
		$this->db->join('kategori_nilai', 'kategori_nilai.id_kategorinilai = nilai_siswa.kategori_nilai_id');
		$this->db->where('nisn',$nisn);
		$this->db->where('mapel_id',$mapel);
		$data = $this->db->get('nilai_siswa');
		return $data->result_array();
	}
	function edit_nilai_siswa($nisn, $mapel, $id_jenis,$id_kategori,$nilai_input)
	{
		$inputan['nilai_siswa'] = $nilai_input;
		$this->db->where('nisn',$nisn);
		$this->db->where('mapel_id',$mapel);
		$this->db->where('jenis_na_id',$id_jenis);
		$this->db->where('kategori_nilai_id',$id_kategori);
		
		$this->db->update("nilai_siswa", $inputan);
	}

	function range_nilai()
	{
		$data = $this->db->get("range_nilai_ekskul");
		return $data->result_array();
	}
}