<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mpresensi extends CI_Model {
	function simpan_presensi($inputan)
	{
		$this->db->insert('presensi_siswa_mapel',$inputan);
		$id_presensi=$this->db->insert_id();
		return $id_presensi;
	}
	function simpan_detail_presensi($kehadiran){
		foreach ($kehadiran as $key => $value) {
			$this->db->insert('detail_presensi_siswa_mapel',$value);
		}
	}
	function cari_id_presensi($kelas, $ta, $mapel, $bulan, $semester){
		$data = $this->db->query("SELECT * FROM presensi_siswa_mapel WHERE id_tahunajaran ='$ta' AND id_mapel='$mapel' AND semester='$semester' AND MONTH(bulan) ='$bulan' AND id_kelas_reguler_berjalan ='$kelas'");
		return $data->result_array();
	}
	function tampil_presensi_by_id_presensi_siswa_mapel($id_presensi)
	{
		$this->db->where('id_presensi_siswa_mapel',$id_presensi);
		$data = $this->db->get('detail_presensi_siswa_mapel');
		return $data->result_array();
	}
	
	function tampil_presensi() {
		$query=$this->db->query("SELECT bulan, namamapel.nama_mapel,SUM(hadir) as hadir,SUM(izin) as izin, SUM(alfa) as alfa FROM detail_presensi_siswa_mapel JOIN presensi_siswa_mapel ON presensi_siswa_mapel.id_presensi_siswa_mapel = detail_presensi_siswa_mapel.id_presensi_siswa_mapel JOIN mapel ON mapel.id_mapel = presensi_siswa_mapel.id_mapel JOIN namamapel ON mapel.id_namamapel= namamapel.id_namamapel GROUP BY bulan, presensi_siswa_mapel.id_mapel");
		return $query->result_array();
	}
	function tampil_bulan_presensi($tahun){
		$bulan=array();
		$data = $this->db->query("SELECT bulan FROM presensi_siswa_mapel WHERE YEAR(bulan)='$tahun' GROUP BY MONTH(bulan)");
		$semua_data=$data->result_array();
		foreach ($semua_data as $key => $value) {
			$bulan[date("m",strtotime($value['bulan']))] = date("F",strtotime($value['bulan']));
		}
		return $bulan;
	}
	function detail_siswa_krb($id_siswa){
		$this->db->Where('id_siswa_kelas_reguler_berjalan',$id_siswa);
		$this->db->join('siswa','siswa.nisn=siswa_kelas_reguler_berjalan.nisn');
		$data = $this->db->get('siswa_kelas_reguler_berjalan');
		return $data->row_array();
	}

	function tampil_presensi_by_bulan_kelas($inputan)
	{
		$kelas=$inputan['kelas_grafik'];	
		$tgl_dari=$inputan['tgl_dari'];	
		$tgl_sampai=$inputan['tgl_sampai'];

		$data=$this->db->query("SELECT * FROM presensi_siswa_mapel
			JOIN mapel ON mapel.id_mapel=presensi_siswa_mapel.id_mapel
			JOIN namamapel ON namamapel.id_namamapel = mapel.id_namamapel
			WHERE id_kelas_reguler_berjalan='$kelas' AND bulan BETWEEN '$tgl_dari' AND '$tgl_sampai'");
		
		$data_presensi = $data->result_array();
		$mp = array();
		$sp = array();

		foreach ($data_presensi as $key => $value) 
		{
			$mp[$value['nama_mapel']][]=$value['id_presensi_siswa_mapel'];
		}	

		foreach ($mp as $nama_mapel => $value_mp)
		{
			$sp[$nama_mapel]["hadir"]=0;
			$sp[$nama_mapel]["izin"]=0;
			$sp[$nama_mapel]["alfa"]=0;
			foreach ($value_mp as $index => $id_psm)
			{
				$siswa_presensi=$this->tampil_presensi_by_id_presensi_siswa_mapel($id_psm);
				foreach ($siswa_presensi as $key => $value_sp) {
					$sp[$nama_mapel]["hadir"]+=$value_sp['hadir'];
					$sp[$nama_mapel]["izin"]+=$value_sp['izin'];
					$sp[$nama_mapel]["alfa"]+=$value_sp['alfa'];
				}
			}
		}
		return $sp;
	}
	
	function tampil_presensi_by_tahun($inputan)
	{

		$tahun_dari =date("Y",strtotime($inputan['tgl_dari']));
		$tahun_sampai =date("Y",strtotime($inputan['tgl_sampai']));

		$data=$this->db->query("SELECT * FROM presensi_siswa_mapel
			WHERE YEAR(bulan) BETWEEN '$tahun_dari' AND '$tahun_sampai'");
		
		$data_presensi = $data->result_array();
		$tp = array();
		$tahun_presensi = array();
		foreach ($data_presensi as $key => $value) 
		{
			$tp[date("Y",strtotime($value['bulan']))][]=$value['id_presensi_siswa_mapel'];
		}	

		foreach ($tp as $tahun => $value_tp)
		{
			$tahun_presensi[$tahun]["hadir"]=0;
			$tahun_presensi[$tahun]["izin"]=0;
			$tahun_presensi[$tahun]["alfa"]=0;
			foreach ($value_tp as $key => $id_psm)
			{
				$siswa_presensi=$this->tampil_presensi_by_id_presensi_siswa_mapel($id_psm);
				foreach ($siswa_presensi as $key => $value_sp) {
					$tahun_presensi[$tahun]["hadir"]+=$value_sp['hadir'];
					$tahun_presensi[$tahun]["izin"]+=$value_sp['izin'];
					$tahun_presensi[$tahun]["alfa"]+=$value_sp['alfa'];
				}
			}
		}
		return $tahun_presensi;
	}

	function kelas_siswa_login($nisn,$semester)
	{
		$data = $this->db->query("SELECT * FROM siswa_kelas_reguler_berjalan
			JOIN kelas_reguler_berjalan ON kelas_reguler_berjalan.id_kelas_reguler_berjalan = siswa_kelas_reguler_berjalan.id_kelas_reguler_berjalan
			JOIN tahunajaran ON tahunajaran.id_tahun_ajaran = kelas_reguler_berjalan.id_tahun_ajaran
			JOIN kelas_reguler ON kelas_reguler.id_kelas_reguler = kelas_reguler_berjalan.id_kelas_reguler
			WHERE nisn ='$nisn' AND tahunajaran.semester = '$semester'");
		return $data->result_array();
	}

	function presensi_siswa_login($id_kelas_reguler_berjalan,$dari,$sampai)
	{
		$data = $this->db->query("SELECT * FROM presensi_siswa_mapel 
			JOIN mapel ON mapel.id_mapel = presensi_siswa_mapel.id_mapel
			JOIN namamapel ON namamapel.id_namamapel = mapel.id_namamapel
			WHERE id_kelas_reguler_berjalan = '$id_kelas_reguler_berjalan' AND bulan BETWEEN '$dari' AND '$sampai'");
		return $data->result_array();
	}
	function detail_presensi_siswa_login($id_presensi_siswa_mapel,$id_siswa_kelas_reguler_berjalan)
	{
		$this->db->where('id_presensi_siswa_mapel',$id_presensi_siswa_mapel);
		$this->db->where('id_siswa_kelas_reguler_berjalan',$id_siswa_kelas_reguler_berjalan);
		$data = $this->db->get('detail_presensi_siswa_mapel');
		return $data ->result_array();
	}
	function tampil_presensi_per_mapel($id_mapel, $id_kelas_reguler_berjalan)
	{
		$data = $this->db->query("SELECT MONTH(bulan) as bulan, sum(hadir) as hadir,  sum(izin) as izin,  sum(alfa) as alfa FROM presensi_siswa_mapel
			JOIN detail_presensi_siswa_mapel ON detail_presensi_siswa_mapel.id_presensi_siswa_mapel = presensi_siswa_mapel.id_presensi_siswa_mapel
			WHERE id_kelas_reguler_berjalan = '$id_kelas_reguler_berjalan' AND id_mapel = '$id_mapel'
			GROUP BY MONTH(bulan)");
		return $data->result_array();
	}
	function presensi_siswa_login_by_kelas($id_kelas_reguler_berjalan)
	{
		$data = $this->db->query("SELECT * FROM presensi_siswa_mapel
			JOIN mapel ON mapel.id_mapel = presensi_siswa_mapel.id_mapel
			JOIN namamapel ON namamapel.id_namamapel = mapel.id_namamapel
			WHERE id_kelas_reguler_berjalan = '$id_kelas_reguler_berjalan'");
		return $data->result_array();
	}
	function jumlah_pertemuan_per_mapel($id_mapel)
	{
		$this->db->where('id_mapel',$id_mapel);
		$data = $this->db->get ('jumlah_pertemuan');
		return $data->row_array();
	}
}
?>