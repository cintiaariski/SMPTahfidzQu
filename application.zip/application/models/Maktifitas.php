<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Maktifitas extends CI_Model
{
	function detail_siswa($nisn)
	{
		$this->db->where("nisn", $nisn);
		$data =	$this->db->get("siswa");
		return $data->row_array();
	}

	function simpan_aktifitas($inputan,$nisn)
	{
		
		$detail_siswa = $this->detail_siswa($nisn);
		$poin = $detail_siswa['poin'];

		if ($inputan['status'] == "pelanggaran") 
		{
			$sisa_poin = $poin - $inputan['poin'];
		}
		else
		{
			$sisa_poin = $poin + $inputan['poin'];
		}
		
		$inputan['sisa_poin']=$sisa_poin;
		$inputan['nisn']=$nisn;
		$this->db->insert("aktivitas", $inputan);

		$this->db->set('poin', $sisa_poin);
		$this->db->where("nisn", $inputan['nisn']);
		$this->db->update("siswa");
	}

	function tampil_aktivitas(){
		$data=$this->db->get("aktivitas");
		$semua_data=$data->result_array();

		return $semua_data;
	}
	function detail_aktivitas($id_aktivitas){
		$this->db->where('id_aktivitas',$id_aktivitas);
		$data= $this->db->get("aktivitas");
		return $data->row_array();
	}
	function edit_aktivitas($inputan,$id_aktivitas)
	{
		$this->db->where('id_aktivitas',$id_aktivitas);
		$this->db->update('aktivitas',$inputan);
	}

	function hapus_aktivitas($id_aktivitas,$nisn)
	{	$detail_aktivitas = $this->detail_aktivitas($id_aktivitas);
		$detail_siswa = $this->detail_siswa($nisn);
		$poin= $detail_aktivitas['poin'];
		$sisa_poin=$detail_siswa['poin'];

		if ($detail_aktivitas['status']=='pelanggaran') {
			$update_poin_siswa= $sisa_poin +$poin;
		} else{
			$update_poin_siswa= $sisa_poin -$poin;
		}
		$nisn= $detail_aktivitas['nisn'];
		$this->db->query("UPDATE siswa SET poin='$update_poin_siswa' WHERE nisn='$nisn'");
		$this->db->where('id_aktivitas',$id_aktivitas);
		$this->db->delete('aktivitas');
	}

	function aktivitas_siswa($nisn){
		$this->db->where('nisn',$nisn);
		$data= $this->db->get('aktivitas');
		return $data->result_array();
	}
	function cari_poin_pelanggaran($jenis){
		$data = $this->db->query("SELECT * FROM jenis_aktivitas WHERE status_aktivitas='pelanggaran'  AND jenis_aktivitas ='$jenis'");
		return $data->result_array();
	}

	function jenis_aktivitas($id_jenis_aktivitas){
		
		$this->db->where("id_jenis_aktivitas",$id_jenis_aktivitas);
		$data=$this->db->get("jenis_aktivitas");

		return $data->row_array();
	}
	function tampil_jenis_aktivitas(){
		$data=$this->db->get("jenis_aktivitas");
		$semua_data=$data->result_array();

		return $semua_data;

	}
	// function tambah_jenis_aktivitas(){
	// 	$detail['status']$this->input->post('status_aktivitas');
	// 	$detail['jenis']$this->input->post('jenis_aktivitas');
	// }
	function edit_jenis_aktivitas($inputan , $id_jenis_aktivitas) {
		$this->db->where('id_jenis_aktivitas',$id_jenis_aktivitas);
		$this->db->update('jenis_aktivitas',$inputan);
	}
	function hapus_jenis_aktivitas($id_jenis_aktivitas){
		$this->db->where("id_jenis_aktivitas", $id_jenis_aktivitas);
		$this->db->delete('jenis_aktivitas');
	}
	function simpan_jenis_aktivitas($inputan)
	{
		$this->db->insert("jenis_aktivitas",$inputan); 
	}

	function detail_jenis_aktivitas($id_jenis_aktivitas){
		$this->db->where("id_jenis_aktivitas",$id_jenis_aktivitas);
		$data = $this->db->get("jenis_aktivitas");
		return $data->row_array();
	}

	function tampil_status_by_periode($inputan)
	{
		$status=$inputan['status'];	
		$tgl_dari=$inputan['tgl_dari'];	
		$tgl_sampai=$inputan['tgl_sampai'];

		$data = $this->db->query("SELECT * FROM aktivitas WHERE status = '$status' AND tgl_aktivitas BETWEEN '$tgl_dari' AND '$tgl_sampai'");

		return $data->result_array();
	}

	function tampil_aktivitas_siswa_ta($nisn,$tahun_ajaran)
	{
		$this->db->where('nisn',$nisn);
		$this->db->where('id_tahun_ajaran',$tahun_ajaran);
		$data = $this->db->get ('aktivitas');
		return $data->result_array();
	}
	
}

?>
