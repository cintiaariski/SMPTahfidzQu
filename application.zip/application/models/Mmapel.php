<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mmapel extends CI_Model {
	function tampil_mapel_kelas_reguler($kelas)
	{
		$this->db->where('id_kelas_reguler',$kelas);
		$this->db->join('namamapel','namamapel.id_namamapel=mapel.id_namamapel');
		$data = $this->db->get('mapel');
		return $data->result_array();
	}
	function detail_mapel($id_mapel)
	{
		$this->db->join('namamapel','namamapel.id_namamapel = mapel.id_namamapel');
		$this->db->where('id_mapel',$id_mapel);
		$data = $this->db->get('mapel');
		return $data->row_array(); 
	}
	function simpan_jumlah_pertemuan($kolom_db){
		$this->db->insert('jumlah_pertemuan',$kolom_db);
	}
	function tampil_jumlah_pertemuan()
	{
		$this->db->join('mapel','mapel.id_mapel = jumlah_pertemuan.id_mapel');
		$this->db->join('namamapel','namamapel.id_namamapel = mapel.id_namamapel');
		$this->db->join('kelas_reguler_berjalan','kelas_reguler_berjalan.id_kelas_reguler_berjalan = mapel.id_kelas_reguler');
		$this->db->join('kelas_reguler','kelas_reguler.id_kelas_reguler = kelas_reguler_berjalan.id_kelas_reguler');
		$this->db->join('tahunajaran','tahunajaran.id_tahun_ajaran = kelas_reguler_berjalan.id_tahun_ajaran');
		$data = $this->db->get("jumlah_pertemuan");
		return $data->result_array();
	}

	function hapus_pertemuan($id_jumlah_pertemuan)
	{

		$this->db->where('id_jumlah_pertemuan',$id_jumlah_pertemuan);
		$this->db->delete('jumlah_pertemuan');
	}
}
?>