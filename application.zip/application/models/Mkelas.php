<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mkelas extends CI_Model {
	function detail_kelas_reguler_bjln($id_kelas_reguler,$id_tahun) 
	{
		$this->db->where('id_kelas_reguler',$id_kelas_reguler);
		$this->db->where('id_tahun_ajaran',$id_tahun);
		$data= $this->db->get('kelas_reguler_berjalan');
		return $data->row_array();
	}

	function siswa_kelas_reguler_brjln($id_kelas_reguler_bjln)
	{
		$this->db->where('id_kelas_reguler_berjalan',$id_kelas_reguler_bjln);
		$this->db->join('siswa','siswa.nisn=siswa_kelas_reguler_berjalan.nisn');
		$this->db->order_by('poin','desc');
		$data=$this->db->get('siswa_kelas_reguler_berjalan');
		return $data->result_array();	
	}
	function tampil_kelas_by_ta($id_tahun_ajaran)
	{
		$this->db->where('id_tahun_ajaran',$id_tahun_ajaran);
		$this->db->join('kelas_reguler','kelas_reguler.id_kelas_reguler = kelas_reguler_berjalan.id_kelas_reguler');
		$this->db->order_by('jenjang','asc');
		$data = $this->db->get('kelas_reguler_berjalan');
		return $data->result_array();
	}
	function tampil_kelas_siswa_login($nisn, $ta){
		$this->db->join('kelas_reguler_berjalan','kelas_reguler_berjalan.id_kelas_reguler_berjalan = siswa_kelas_reguler_berjalan.id_kelas_reguler_berjalan');
		$this->db->join('tahunajaran','tahunajaran.id_tahun_ajaran = kelas_reguler_berjalan.id_tahun_ajaran');
		$this->db->where("nisn",$nisn);
		$this->db->where("kelas_reguler_berjalan.id_tahun_ajaran",$ta);
		$data = $this->db->get ('siswa_kelas_reguler_berjalan');
		return $data->row_array();

	}

	
}
?>