<?php 
class Mekskul extends CI_Model
{	
	function tampil_jenis_kelas_tambahan()
	{
		$data = $this->db->get("jenis_kls_tambahan");
		return $data->result_array();
	}
	
	function tampil_jadwal_ekskul($id_ta)
	{
		$this->db->join("pembimbing", "pembimbing.id_pembimbing = jadwal_ekskul.id_pembimbing");
		$this->db->join("pegawai", "pegawai.NIP = pembimbing.nip");
		$this->db->join("jenis_kls_tambahan", "jenis_kls_tambahan.id_jenis_kls_tambahan = pembimbing.id_jenis_kls_tambahan");
		$this->db->where("pembimbing.id_tahun_ajaran",$id_ta);
		$data = $this->db->get("jadwal_ekskul");
		return $data->result_array();
	}

	function tampil_pembimbing_ekstra($id_ta)
	{
		$this->db->where("id_tahun_ajaran",$id_ta);
		$this->db->join("pegawai", "pegawai.NIP = pembimbing.nip");
		$this->db->join("jenis_kls_tambahan",'jenis_kls_tambahan.id_jenis_kls_tambahan=pembimbing.id_jenis_kls_tambahan');
		$data =$this->db->get("pembimbing");
		return $data->result_array();
	}

	function simpan_jadwal_ekskul($inputan)
	{
		$this->db->insert("jadwal_ekskul", $inputan);
	}

	function simpan_ekskul($inputan)
	{
		$this->db->insert("jenis_kls_tambahan", $inputan);
	}

	function tampil_ekskul()
	{
		$data = $this->db->get("jenis_kls_tambahan");
		return $data->result_array();		
	}

	function simpan_pembimbing($inputan)
	{
		$this->db->insert("pembimbing",$inputan); 
	}

	function hapus_pembimbing($id_pembimbing)
	{

		$this->db->where('id_pembimbing',$id_pembimbing);
		$this->db->delete('pembimbing');
	}
	function hapus_ekskul($id_jenis_kls_tambahan)
	{
		$this->db->where("id_jenis_kls_tambahan",$id_jenis_kls_tambahan);
		$this->db->delete('jenis_kls_tambahan');	
	}
	function edit_jadwal_ekskul($inputan,$id_jadwal_ekskul){

		$this->db->where('id_jadwal_ekskul',$id_jadwal_ekskul);
		$this->db->update('jadwal_ekskul',$inputan);
	}
	function hapus_jadwal_ekskul($id_jadwal_ekskul){
		$this->db->where("id_jadwal_ekskul",$id_jadwal_ekskul);
		$this->db->delete('jadwal_ekskul');
	}
	function detail_ekskul($id_jadwal_ekskul){
		$this->db->where("id_jadwal_ekskul",$id_jadwal_ekskul);
		$data=$this->db->get("jadwal_ekskul");

		return $data->row_array();
	}

	function hari()
	{
		$hari = array("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu");
		return $hari;
	}

	function tampil_pembimbing_extra($id_extra, $id_ta)
	{
		$this->db->join("pegawai", "pegawai.NIP = pembimbing.nip");
		$this->db->where("id_jenis_kls_tambahan",$id_extra);
		$this->db->where("id_tahun_ajaran", $id_ta);
		$data = $this->db->get("pembimbing");
		return $data->result_array();
	}

	function tampil_peserta_ekskul_by_ta($id_ta)
	{
		$sql = $this->db->query("SELECT jenis_kls_tambahan.id_jenis_kls_tambahan, jenis_kls_tambahan.jenis_kls_tambahan, siswa.nisn, siswa.nama FROM ekstrakurikuler
			JOIN jadwal_ekskul ON jadwal_ekskul.id_jadwal_ekskul = ekstrakurikuler.id_jadwal_ekskul
			JOIN pembimbing ON pembimbing.id_pembimbing = jadwal_ekskul.id_pembimbing
			JOIN jenis_kls_tambahan ON jenis_kls_tambahan.id_jenis_kls_tambahan = pembimbing.id_jenis_kls_tambahan
			JOIN siswa ON siswa.nisn = ekstrakurikuler.nisn
			WHERE pembimbing.id_tahun_ajaran = '$id_ta'");

		$peserta= $sql->result_array();
		
		$data_peserta['daftar_peserta'] = array();
		foreach ($peserta as $key => $value) 
		{
			$data_peserta['daftar_peserta'][$value['id_jenis_kls_tambahan']]['nama_extra'] = $value['jenis_kls_tambahan'];
			$data_peserta['daftar_peserta'][$value['id_jenis_kls_tambahan']]['peserta'][$value['nisn']] = $value['nama'];
		}

		foreach ($data_peserta['daftar_peserta'] as $id_jenis => $value) 
		{
			$data_peserta['jumlah'][$id_jenis]=count($value['peserta']);
		}
		return $data_peserta;
	}

	function simpan_peserta_ekskul($id_jadwal,$nisn)
	{
		$kolom['id_jadwal_ekskul'] = $id_jadwal;
		$kolom['nisn'] = $nisn;
		$this->db->insert('ekstrakurikuler',$kolom);
	}

	function tampil_ta_ekskul()
	{
		$this->db->join('tahunajaran','tahunajaran.id_tahun_ajaran = pembimbing.id_tahun_ajaran','left');
		$data = $this->db->get('pembimbing');
		return $data->result_array();
	}

	function tampil_ekskul_per_hari($id_ta)
	{
		$this->db->join('pembimbing','pembimbing.id_pembimbing = jadwal_ekskul.id_pembimbing');
		$this->db->join('jenis_kls_tambahan','jenis_kls_tambahan.id_jenis_kls_tambahan = pembimbing.id_jenis_kls_tambahan');
		$this->db->where('pembimbing.id_tahun_ajaran',$id_ta);
		$data = $this->db->get('jadwal_ekskul');
		$jadwal_ekskul_ta = $data->result_array();
		
		foreach ($jadwal_ekskul_ta as $key => $value)
		{
			$jadwal_ekskul[$value['id_jenis_kls_tambahan']][$value['id_jadwal_ekskul']][$value['hari']] =date("G:i",strtotime($value['jam_mulai']))." -" .date("G:i",strtotime($value['jam_selesai']));
		} 
		return $jadwal_ekskul;
	}
	function jadwal_ekskul_per_hari($id_ta,$nip){
		$this->db->join('pembimbing','pembimbing.id_pembimbing = jadwal_ekskul.id_pembimbing');
		$this->db->join('jenis_kls_tambahan','jenis_kls_tambahan.id_jenis_kls_tambahan = pembimbing.id_jenis_kls_tambahan');
		$this->db->where('pembimbing.id_tahun_ajaran',$id_ta);
		$this->db->where('pembimbing.nip',$nip);
		$data = $this->db->get('jadwal_ekskul');
		$jadwal_ekskul_ta = $data->result_array();
		$jadwal_ekskul=array();
		foreach ($jadwal_ekskul_ta as $key => $value)
		{
			$jadwal_ekskul[$value['id_jadwal_ekskul']][$value['hari']]= date("G:i",strtotime($value['jam_mulai']))."-".date("G:i",strtotime($value['jam_selesai']));
		}
		return $jadwal_ekskul;
	}
	function detail_pembimbing($id_pembimbing){
		$this->db->where('id_pembimbing',$id_pembimbing);
		$data=$this->db->get('pembimbing');
		return $data->row_array();
	}
	function tampil_ekskul_pembimbing($nip,$id_ta)
	{
		$this->db->join('jenis_kls_tambahan','jenis_kls_tambahan.id_jenis_kls_tambahan = pembimbing.id_jenis_kls_tambahan');
		$this->db->where('nip',$nip);
		$this->db->where('id_tahun_ajaran',$id_ta);
		$data = $this->db->get('pembimbing');
		return $data->row_array();
	}
	function tampil_jadwal_pembimbing($id_pembimbing)
	{
		$this->db->where('id_pembimbing',$id_pembimbing);
		$data = $this->db->get ('jadwal_ekskul');
		return $data->result_array();
	}
	function tampil_jadwal_siswa_ekskul($id_jadwal_ekskul)
	{
		$this->db->join('siswa','siswa.nisn = ekstrakurikuler.nisn');
		$this->db->where('id_jadwal_ekskul',$id_jadwal_ekskul);
		$data = $this->db->get('ekstrakurikuler');
		return $data->result_array();
	}
	function konvert_nilai($nilai)
	{
		$data = $this->db->get("range_nilai_ekskul");
		$data_nilai = $data->result_array();
		
		$konvert_nilai = "";
		foreach ($data_nilai as $key => $value)
		{
			if ($nilai >= $value['nilai_min'] && $nilai <= $value['nilai_max']) 
			{
				$konvert_nilai = $value['nilai_konversi'];
			}
		}

		return $konvert_nilai;
	}
	function simpan_nilai_ekskul($id_pembimbing,$nisn,$nilai){
		$simpan["nisn"] = $nisn;
		$nilai = $this->konvert_nilai($nilai);
		$simpan["nilai_ekskul"] = $nilai;
		$simpan["id_pembimbing"] = $id_pembimbing;
		
		$data = $this->db->query("SELECT * FROM nilaiekskul WHERE nisn = '$nisn' AND id_pembimbing = '$id_pembimbing' ");
		$cari = $data->num_rows();

		if ($cari == 1){
			$this->db->where('nisn',$nisn);
			$this->db->where('id_pembimbing',$id_pembimbing);
			$this->db->update('nilaiekskul',$simpan);
		}
		else
		{
			$this->db->insert('nilaiekskul',$simpan);
		}
	}
	function tampil_nilai($id_pembimbing)
	{
		$this->db->join('siswa', 'siswa.nisn = nilaiekskul.nisn');
		$this->db->where('id_pembimbing',$id_pembimbing);
		$data = $this->db->get ('nilaiekskul');

		return $data->result_array();
	}
	function tampil_nilai_siswa_ta($nisn,$tahun_ajaran)
	{
		$this->db->where('nisn',$nisn);
		$this->db->where('pembimbing.id_tahun_ajaran',$tahun_ajaran);
		$this->db->join('pembimbing','pembimbing.id_pembimbing = nilaiekskul.id_pembimbing');
		$this->db->join('jenis_kls_tambahan','jenis_kls_tambahan.id_jenis_kls_tambahan = pembimbing.id_jenis_kls_tambahan');
		$data = $this->db->get ('nilaiekskul');
		return $data->result_array();
	}
	function tampil_jenis_kelas_tambahan_by_ta($id_ta){
		$this->db->where ('id_tahun_ajaran',$id_ta);
		$this->db->join('jenis_kls_tambahan','jenis_kls_tambahan.id_jenis_kls_tambahan = pembimbing.id_jenis_kls_tambahan');
		$this->db->group_by('pembimbing.id_jenis_kls_tambahan');
		$data = $this->db->get('pembimbing');
		return $data-> result_array();
	}
	function tampil_pembimbing($id_ta)
	{
		$data = $this->db->query("SELECT * FROM pegawai WHERE NIP NOT IN (SELECT NIP FROM pembimbing) AND status_pensiun != 'pensiun' ORDER BY Nama ASC");
		$pegawai = $data->result_array();
		return $pegawai;
	}
}

?>