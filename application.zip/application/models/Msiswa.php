<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Msiswa extends CI_Model {
	function detail_siswa_by_nisn($nisn)
	{
		$this->db->where('nisn',$nisn);
		$data =$this->db->get('siswa');
		return $data->row_array();
	}

}
?>
