 	$data['nilai_siswa'] = array();
  	$data['jenis_ujian'] = array();
  	$data['mapel_input'] = array();

  	$input = $this->input->post();

  	if ($input) 
  	{
  		$nilai_siswa = $this->Mnilai->nilai_siswa($input['mapel']);

  		foreach ($nilai_siswa as $key => $value_ns) 
  		{
  			if ($value_ns['nisn'] == $nisn) 
  			{
  				$data['nilai_siswa'][$value_ns['jenis_na']][$value_ns['kategori_nilai']][]= $value_ns['nilai_siswa'];

  				$data['jenis_ujian'][$value_ns['jenis_na']][$value_ns['id_kategorinilai']][$value_ns['kategori_nilai']] = count(
  					$data['nilai_siswa'][$value_ns['jenis_na']][$value_ns['kategori_nilai']]);
  			}
  		}
  		$data ['mapel_input'] = $input['mapel'];
  	}