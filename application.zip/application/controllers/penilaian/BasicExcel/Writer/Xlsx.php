<?php

namespace BasicExcel\Writer;

class Xlsx extends \BasicExcel\Writer\Xls {
    
}